
plugins {
    groovy // <1>

    application // <2>
}

repositories {
    jcenter() // <3>
}

dependencies {
    implementation("org.codehaus.groovy:groovy-all:2.5.13") // <4>

    implementation("com.google.guava:guava:29.0-jre") // <5>

    testImplementation("org.spockframework:spock-core:1.3-groovy-2.5") // <6>
    testImplementation("junit:junit:4.13")
}

application {
    mainClass.set("demo.App") // <7>
}
