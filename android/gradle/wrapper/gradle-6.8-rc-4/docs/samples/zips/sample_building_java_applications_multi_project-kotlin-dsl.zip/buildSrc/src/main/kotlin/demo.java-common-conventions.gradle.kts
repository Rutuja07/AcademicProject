
plugins {
    java // <1>
}

repositories {
    jcenter() // <2>
}

dependencies {
    constraints {
        implementation("org.apache.commons:commons-text:1.9") // <3>
    }

    testImplementation("org.junit.jupiter:junit-jupiter-api:5.6.2") // <4>

    testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine") // <5>
}

tasks.test {
    useJUnitPlatform() // <6>
}
