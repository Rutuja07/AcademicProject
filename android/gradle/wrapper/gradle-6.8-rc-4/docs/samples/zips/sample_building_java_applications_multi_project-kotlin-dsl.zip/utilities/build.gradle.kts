
plugins {
    id("demo.java-library-conventions")
}

dependencies {
    api(project(":list"))
}
