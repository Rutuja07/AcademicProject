
plugins {
    id("demo.kotlin-common-conventions") // <1>

    application // <2>
}
