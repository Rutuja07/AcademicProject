
plugins {
    id("demo.kotlin-common-conventions") // <1>

    `java-library` // <2>
}
