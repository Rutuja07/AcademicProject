
plugins {
    id("demo.scala-common-conventions") // <1>

    application // <2>
}
