
plugins {
    scala // <1>
}

repositories {
    jcenter() // <2>
}

dependencies {
    constraints {
        implementation("org.apache.commons:commons-text:1.9") // <3>

        implementation("org.scala-lang:scala-library:2.13.3")
    }

    implementation("org.scala-lang:scala-library") // <4>

    testImplementation("org.junit.jupiter:junit-jupiter-api:5.6.2") // <5>

    testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine") // <6>
}

tasks.test {
    useJUnitPlatform() // <7>
}
