
plugins {
    id("demo.scala-library-conventions")
}
