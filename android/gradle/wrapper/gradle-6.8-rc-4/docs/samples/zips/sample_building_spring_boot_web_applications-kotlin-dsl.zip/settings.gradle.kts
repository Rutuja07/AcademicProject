rootProject.name = "spring-boot-demo"

include("app")
