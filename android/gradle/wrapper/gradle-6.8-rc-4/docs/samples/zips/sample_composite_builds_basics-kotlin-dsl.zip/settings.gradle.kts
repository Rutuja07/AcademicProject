rootProject.name = "my-composite"

includeBuild("my-app")
includeBuild("my-utils")
