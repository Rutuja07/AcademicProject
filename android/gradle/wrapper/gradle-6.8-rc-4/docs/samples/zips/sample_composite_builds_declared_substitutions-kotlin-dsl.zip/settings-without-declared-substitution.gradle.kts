rootProject.name = "declared-substitution"

include("app")

includeBuild("anonymous-library")
