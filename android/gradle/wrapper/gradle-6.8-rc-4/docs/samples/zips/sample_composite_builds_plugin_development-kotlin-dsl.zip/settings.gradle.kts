rootProject.name = "consumer"

include("my-greeting-app")

// To function outside a composite, a plugin repository would be required here
