module org.gradle.sample.list {
    exports org.gradle.sample.list;
}
