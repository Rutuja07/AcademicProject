plugins {
    `kotlin-dsl`
}

repositories {
    jcenter()
}
