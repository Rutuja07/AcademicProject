rootProject.name = "convention-plugins"

include("convention-plugins")
