plugins {
    id("myproject.java-conventions")
    id("java-library")
}
